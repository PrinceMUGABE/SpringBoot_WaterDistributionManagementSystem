package com.example.water;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaterDistributerApplicationTests {

    @Test
    void contextLoads() {
    }

}
