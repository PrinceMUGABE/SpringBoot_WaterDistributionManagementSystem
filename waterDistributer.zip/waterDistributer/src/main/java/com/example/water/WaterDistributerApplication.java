package com.example.water;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaterDistributerApplication {

    public static void main(String[] args) {
        SpringApplication.run(WaterDistributerApplication.class, args);
    }

}
